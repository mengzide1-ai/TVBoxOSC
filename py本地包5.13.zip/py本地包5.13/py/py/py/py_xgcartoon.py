#coding=utf-8
#!/usr/bin/python
import sys
sys.path.append('..')
from base.spider import Spider
import re
from urllib import request, parse
import urllib
import urllib.request
from lxml import etree
import json
import ssl
ssl._create_default_https_context = ssl._create_unverified_context#全局取消证书验证
import requests

class Spider(Spider):  # 元类 默认的元类 type
	def getName():
		return "西瓜卡通"
	def __init__(self,extend=""):
		self.config['filter']['jp']=self.config['filter']['cn']
		self.config['filter']['kr']=self.config['filter']['cn']
		self.config['filter']['*']=self.config['filter']['cn']
	def init(self, extend=""):
		print("============{0}============".format(extend))
		pass
	def isVideoFormat(self,url):
		pass
	def manualVideoCheck(self):
		pass
	def homeContent(self,filter):
		result = {}
		cateManual = {
			"国漫": "cn",
			"日漫":"jp",
			"韩漫":"kr",
			"全部":"*"
		}
		classes = []
		for k in cateManual:
			classes.append({
				'type_name':k,
				'type_id':cateManual[k]
			})
		result['class'] = classes
		if(filter):
			result['filters'] = self.config['filter']
		return result
	def homeVideoContent(self):
		htmlTxt =self.custom_webReadFile(urlStr='https://cn.xgcartoon.com/')#div[@class="box"]
		root = self.html(htmlTxt)
		nodes = root.xpath('//div[contains(@class, "box")]')
		videos = self.custom_list(liList=nodes)
		result = {
			'list':videos
		}
		return result
	def categoryContent(self,tid,pg,filter,extend):
		result = {}
		videos=[]
		classification='*'
		if 'classification' in extend.keys():
			classification=extend['classification']
		Url='https://cn.xgcartoon.com/api/amp_query_cartoon_list?type={2}&region={0}&filter=*&filter=*,*,*&page={1}&limit=36&language=*'.format(tid,pg,classification)
		xPath="//div[@class='bor_img3_right']"
		htmlTxt =self.custom_webReadFile(urlStr=Url)
		jRoot=json.loads(htmlTxt)
		nodes = jRoot['items']
		videos =self.custom_list_json(liList=nodes)
		pagecount=0 if len(videos)<35 else int(pg)+1
		result['list'] = videos
		result['page'] = pg
		result['pagecount'] =pagecount
		result['limit'] = 90
		result['total'] = 999999
		return result
	def detailContent(self,array):
		aid = array[0].split('###')
		idUrl=aid[1]
		title=aid[0]
		pic=aid[2]
		playFrom = ['播放']
		htmlTxt =self.custom_webReadFile(urlStr=idUrl)
		
		root = self.html(htmlTxt)
		videoList=[]
		vodItems = []
		circuit=root.xpath('//div[@class="detail-right__volumes mt42"]/div[@class="row"]')
		for v in circuit:
			vodItems=self.custom_EpisodesList(nodes=v)
			joinStr = "#".join(vodItems)
			videoList.append(joinStr)
		vod_play_from='$$$'.join(playFrom)
		vod_play_url = "$$$".join(videoList)

		typeName=''
		dir=''
		cont=''
		try:
			temporary=root.xpath('//div[@class="detail-right__tags"]/div[@class="tag tag-secondary"]/text()')
			if len(temporary)>0:
				typeName='/'.join(temporary).replace('\n          ','')
			temporary=root.xpath('//div[@class="detail-right__desc mt42"]/p/text()')
			if len(temporary)>0:
				cont=temporary[0]
			temporary=root.xpath('//div[@class="detail-right__title"]/div/text()')
			if len(temporary)>0:
				dir=temporary[0].replace('\n          ','')
		except Exception as e:
			raise e
		vod = {
			"vod_id": array[0],
			"vod_name": title,
			"vod_pic": pic,
			"type_name":self.custom_removeHtml(txt=typeName),
			"vod_year": '',
			"vod_area": '',
			"vod_remarks":'',
			"vod_actor":'',
			"vod_director": self.custom_removeHtml(txt=dir),
			"vod_content": self.custom_removeHtml(txt=cont)
		}
		vod['vod_play_from'] = vod_play_from
		vod['vod_play_url'] = vod_play_url

		result = {
			'list': [
				vod
			]
		}
		return result
	
	def searchContent(self,key,quick):
		key=urllib.parse.quote(key)
		Url='https://cn.xgcartoon.com/search?q={0}'.format(key,'1')
		htmlTxt =self.custom_webReadFile(urlStr=Url)
		root = self.html(htmlTxt)
		nodes = root.xpath('//a[@class="topic-list-item"]')
		videos =self.custom_list_search(liList=nodes)
		result = {
			'list':videos
		}
		return result
	def playerContent(self,flag,id,vipFlags):
		result = {}
		Url=id
		parse=1
		req=requests.get(Url)
		root = self.html(req.text)
		nodes = root.xpath('//div[@id="video_content"]/iframe/@src')
		if len(nodes)>0:
			Url=nodes[0]
		result["parse"] = parse#0=直接播放、1=嗅探
		result["playUrl"] =''
		result["url"] = Url
		# result['jx'] = jx#VIP解析,0=不解析、1=解析
		result["header"] = ''	
		return result
	def localProxy(self,param):
		return [200, "video/MP2T", action, ""]

	config = {
		"player": {},
		"filter": {
		"cn":[
			{"key":"classification","name":"分类","value":[{'n': '全部', 'v': '*'},{'n': '穿越', 'v': 'chuanyue'}, {'n': '科幻', 'v': 'kehuan'}, {'n': '热血', 'v': 'rexue'}, {'n': '电竞', 'v': 'dianjing'}, {'n': '战争', 'v': 'zhanzheng'}, {'n': '动作', 'v': 'dongzuo'}, {'n': '惊悚', 'v': 'jingsong'}, {'n': '灾难', 'v': 'zainan'}, {'n': '医疗', 'v': 'yiliao'}, {'n': '成长', 'v': 'chengzhang'}, {'n': '古装', 'v': 'guzhuang'}, {'n': '友情', 'v': 'youqing'}, {'n': '短篇', 'v': 'duanpian'}, {'n': '少儿', 'v': 'shaoer'}, {'n': '百合', 'v': 'baihe'}, {'n': '真人', 'v': 'zhenren'}, {'n': '剧情', 'v': 'juqing'}, {'n': '推理', 'v': 'tuili'}, {'n': '英雄', 'v': 'yingxiong'}, {'n': '悬疑', 'v': 'xuanyi'}, {'n': '人性', 'v': 'renxing'}, {'n': '机器', 'v': 'jiqi'}, {'n': '小剧场', 'v': 'xiaojuchang'}, {'n': '日常', 'v': 'richang'}, {'n': '萝莉', 'v': 'luoli'}, {'n': '竞技', 'v': 'jingji'}, {'n': '原创', 'v': 'yuanchuang'}, {'n': '可爱', 'v': 'keai'}, {'n': '武侠', 'v': 'wuxia'}, {'n': '益智', 'v': 'yizhi'}, {'n': '历史', 'v': 'lishi'}, {'n': '战斗', 'v': 'zhandou'}, {'n': '都市', 'v': 'dushi'}, {'n': '总裁', 'v': 'zongcai'}, {'n': '治愈', 'v': 'zhiyu'}, {'n': '萌系', 'v': 'mengxi'}, {'n': '修仙', 'v': 'xiuxian'}, {'n': '喜剧', 'v': 'xiju'}, {'n': '古风', 'v': 'gufeng'}, {'n': '神魔', 'v': 'shenmo'}, {'n': '搞笑', 'v': 'gaoxiao'}, {'n': '游戏改', 'v': 'youxigai'}, {'n': '高达', 'v': 'gaoda'}, {'n': '漫画改', 'v': 'manhuagai'}, {'n': '神话', 'v': 'shenhua'}, {'n': '仙侠', 'v': 'xianxia'}, {'n': '恋爱', 'v': 'lianai'}, {'n': '恐怖', 'v': 'kongbu'}, {'n': '军事', 'v': 'junshi'}, {'n': '大女主', 'v': 'danvzhu'}, {'n': '冒险', 'v': 'maoxian'}, {'n': '儿童向', 'v': 'ertongxiang'}, {'n': '早教', 'v': 'zaojiao'}, {'n': '奇幻', 'v': 'qihuan'}, {'n': '音乐', 'v': 'yinyue'}, {'n': '运动', 'v': 'yundong'}, {'n': '偶像', 'v': 'ouxiang'}, {'n': '学英语', 'v': 'xueyingyu'}, {'n': '异世界', 'v': 'yishijie'}, {'n': '动画', 'v': 'donghua'}, {'n': '料理', 'v': 'liaoli'}, {'n': '重生', 'v': 'chongsheng'}, {'n': '小说改', 'v': 'xiaoshuogai'}, {'n': '亲子', 'v': 'qinzi'}, {'n': '末日幻想', 'v': 'morihuanxiang'}, {'n': '少年', 'v': 'shaonian'}, {'n': '魔法', 'v': 'mofa'}, {'n': '少女', 'v': 'shaonv'}, {'n': '玄幻', 'v': 'xuanhuan'}, {'n': '生存', 'v': 'shengcun'}, {'n': '耽美', 'v': 'shenmei'}, {'n': '智斗', 'v': 'zhidou'}, {'n': '救援', 'v': 'jiuyuan'}, {'n': '格斗', 'v': 'gedou'}, {'n': '复仇', 'v': 'fuchou'}, {'n': '动态漫', 'v': 'dongtaiman'}, {'n': '爱情', 'v': 'aiqing'}, {'n': '后宫', 'v': 'hougong'}, {'n': '励志', 'v': 'lizhi'}, {'n': '校园', 'v': 'xiaoyuan'}, {'n': '家庭', 'v': 'jiating'}]}
		]
		}
		}

	header = {
		"Referer": 'http://www.884707.com/',
		'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.54 Safari/537.36',
		"Host":'www.884707.com'
		}
	#-----------------------------------------------自定义函数-----------------------------------------------
		#正则取文本
	def custom_RegexGetText(self,Text,RegexText,Index):
		returnTxt=""
		Regex=re.search(RegexText, Text, re.M|re.S)
		if Regex is None:
			returnTxt=""
		else:
			returnTxt=Regex.group(Index)
		return returnTxt	
	
	#分类取结果
	def custom_list_search(self,liList):
		videos = []
		head="https://cn.xgcartoon.com"
		for v in liList:
			title=v.xpath('./div[@class="topic-list-item__info"]/div[@class="h3 mb12"]/text()')[0]
			
			
			img=v.xpath('./div[@class="topic-list-item__cover"]/amp-img/@src')[0]
			
			url=v.xpath("./@href")[0]
			if url.find('://')<1:
				url=head+url
			if img.find('://')<1:
				img=head+img
			vod_id="{0}###{1}###{2}".format(title,url,img)
			videos.append({
				"vod_id":vod_id,
				"vod_name":title,
				"vod_pic":img,
				"vod_remarks":''
			})
		return videos
	#分类取结果
	def custom_list(self,liList):
		videos = []
		
		head="https://cn.xgcartoon.com"
		for v in liList:
			title=v.xpath('./a[@class="title"]/h3[@class="h3 text-truncate"]/text()')
			
			if len(title)<1:
				continue
			else:
				title=title[0]
			img=v.xpath('./a[@class="cover mb12"]/amp-img/@src')[0]
			
			url=v.xpath('./a[@class="title"]/@href')[0]
			if url.find('://')<1:
				url=head+url
			if img.find('://')<1:
				img=head+img
			vod_id="{0}###{1}###{2}".format(title,url,img)
			print(vod_id)
			videos.append({
				"vod_id":vod_id,
				"vod_name":title,
				"vod_pic":img,
				"vod_remarks":''
			})
		print(len(videos))
		return videos
	#分类取结果
	def custom_list_json(self,liList):
		videos = []
		
		head="https://cn.xgcartoon.com/detail/"
		for v in liList:
			title=v['name']
			img=v['topic_img']
			url=v['cartoon_id']
			if url.find('://')<1:
				url=head+url
			if img.find('://')<1:
				img='https://static-a.xgcartoon.com/cover/{0}'.format(img)
			vod_id="{0}###{1}###{2}".format(title,url,img)
			videos.append({
				"vod_id":vod_id,
				"vod_name":title,
				"vod_pic":img,
				"vod_remarks":''
			})
		return videos
		#访问网页
	def custom_webReadFile(self,urlStr,header=None,codeName='utf-8'):
		html=''
		if header==None:
			header={
				"Referer":urlStr,
				'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.54 Safari/537.36',
				"Host":self.custom_RegexGetText(Text=urlStr,RegexText='https*://(.*?)(/|$)',Index=1)
			}
		# import ssl
		# ssl._create_default_https_context = ssl._create_unverified_context#全局取消证书验证
		req=urllib.request.Request(url=urlStr,headers=header)#,headers=header
		with  urllib.request.urlopen(req)  as response:
			html = response.read().decode(codeName,'ignore')
		return html
	
	#取集数
	def custom_EpisodesList(self,nodes):
		videos = []
		ListA=nodes.xpath('.//a[@class="goto-chapter chapter-box text-truncate"]')
		head="https://cn.xgcartoon.com"
		for vod in ListA:
			title =vod.xpath("./span/text()")[0]
			url = head+vod.xpath("./@href")[0]
			if len(url) == 0:
				continue
			videos.append(title+"$"+url)
		# 	print(title)
		# print('共:'+str(len(videos)))
		return videos
	#取剧集区
	def custom_lineList(self,Txt,mark,after):
		circuit=[]
		origin=Txt.find(mark)
		while origin>8:
			end=Txt.find(after,origin)
			circuit.append(Txt[origin:end])
			origin=Txt.find(mark,end)
		return circuit	
	#正则取文本,返回数组	
	def custom_RegexGetTextLine(self,Text,RegexText,Index):
		returnTxt=[]
		pattern = re.compile(RegexText, re.M|re.S)
		ListRe=pattern.findall(Text)
		if len(ListRe)<1:
			return returnTxt
		for value in ListRe:
			returnTxt.append(value)	
		return returnTxt
	
	#删除html标签
	def custom_removeHtml(self,txt):
		soup = re.compile(r'<[^>]+>',re.S)
		txt =soup.sub('', txt)
		return txt.replace("&nbsp;"," ")
	
# T=Spider()
# print(T.config['filter']['jp'])